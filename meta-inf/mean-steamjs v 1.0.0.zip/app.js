'use strict';

var config 		= require('./config');
//var database 	= require('./services/database');

const cluster 	= require('cluster');  
const numCPUs 	= require('os').cpus().length;

var WORKERS 	= process.env.WEB_CONCURRENCY || 1;

if (cluster.isMaster) {  
	// I'm the master, let's fork !
	for (var i = 0; i < numCPUs; i++) {
		cluster.fork();
	}
	
	cluster.on('online', (worker) => {
		console.log(`Worker ${worker.process.pid} is alive.`);
	});
	
	cluster.on('exit', (worker, code, signal) => {
		console.log(`Worker ${worker.process.pid} died.`);
	});
	
} 
else {
	// I'm a worker, let's spawn the HTTP server
	// (workers can share any TCP connection)
	var init = require('./init.js');
	init();
}


process.on('uncaughtException', function(err) {
	//log the error
	console.error(err);
	//let's tell our master we need to be disconnected
	require('forky').disconnect();
	//in a worker process, this will signal the master that something is wrong
	//the master will immediately spawn a new worker
	//and the master will disconnect our server, allowing all existing traffic to end naturally
	//but not allowing this process to accept any new traffic
});