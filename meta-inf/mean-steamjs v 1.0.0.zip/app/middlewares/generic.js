/**
* Package @ Steam JS - Routes	
* Author  @ psbhanu
*/

module.exports = function (app) {
    // Generic Middlewares
	app.use(function (request, response, next) {
		console.log('Time:', Date.now());
		next();
	});
	app.use(function (request, response, next) {
		response.pageInfo = response.pageInfo || {};
		next();
	});
};