/**
* Package @ Steam JS - Middlewares	
* Author  @ psbhanu
* This module loads dynamically all middleware modules located in the middlewares/ directory.
*/

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = function (app) {
	fs.readdirSync('./app/middlewares').forEach(function (file) {
		// Avoid to read this current file.
		if (file === path.basename(__filename)) { return; }
		
		// Load the middleware file.
		require('./' + file)(app);
	});
};