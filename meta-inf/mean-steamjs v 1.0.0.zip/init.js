const express 	= require('express');
var app 		= express();
//module.exports  = app;

var PORT 		= process.env.PORT || 3000;
var APP_KEY 	= process.env.APP_KEY;


var init = function() {
	const http 		= require('http');
	const path 		= require('path');
	var exphbs   	= require('express-handlebars');
	
	app.set('port', PORT);
	
	/*
		// Configure the application.
		app.configure(function () {
		// ... ... ...
		});
		app.configure('production', function () {
		// ... ... ...
		});
		app.configure('development', function () {
		// ... ... ...
		});
	*/
	
	// views is directory for all template files
	app.set('views', __dirname + '/app/views');
	
	// Use Express-Handlebars 
	app.engine('handlebars', exphbs({
		defaultLayout: 'main',
		layoutsDir: 'app/views/layouts/',
		partialsDir: 'app/views/partials/',
	}));
	app.set('view engine', 'handlebars');
	app.use(express.static(path.join(__dirname, 'static')));
	
	var server = http.createServer(app);
	
	// Load all middlewares.
	require('./app/middlewares')(app);

	// Load all routes.
	require('./routes')(app);
	
	// Listen on http port.
	server.listen(app.get('port'), function(){
		console.log('Express server listening on port ' + app.get('port'));
	});  
}	
module.exports = init;