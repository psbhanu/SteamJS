/**
* Package @ Steam JS - Routes	
* Author  @ psbhanu
*/

var GenericController = require('../app/controllers/generic-controller');

module.exports = function (app) {
    // Generic Routes
    app.get('/', GenericController.Index);
    app.get('/home',  GenericController.Index);
    app.get('/about',  GenericController.About);
};