var config = {};

config.development = {

    database: {
	name: 'MVCApplication',
	host: 'localhost',
	port: '27017',
	credentials: ''
    },
    application: {
	port: 1337
    }
    
};

config.production = {

    database: {
	name: 'tradewinds',
	host: 'localhost',
	port: '8080',
	credentials: 'admin:password@' // username:password@
    },
    application: {
	port: 80
    }    
    
};

config.environment = 'development';

module.exports = config;